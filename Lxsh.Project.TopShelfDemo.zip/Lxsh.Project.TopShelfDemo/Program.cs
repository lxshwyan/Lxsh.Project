﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Lxsh.Project.TopShelfDemo
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>  
         static void Main(string[] args)
        {
            ServiceConfigure.Configure();
        }
    }
}
