﻿using NewLife.RocketMQ;
using NewLife.RocketMQ.Protocol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Lxsh.Project.RoketMQDemo
{
    class Program
    {
      
        static void Main(string[] args)
        {
             string strstrTopic = "SFBR-ABM";
             RoketMQHelper _RoketMQHelper = new RoketMQHelper("192.168.137.252:9876");
            _RoketMQHelper.DelConsumerMsgEvent += _RoketMQHelper_DelConsumerMsgEvent;
            _RoketMQHelper.ConsumerMsg(strstrTopic, "test");
            Console.ReadLine();
           SendMsg(strstrTopic, _RoketMQHelper);
        }
        /// <summary>
        /// 发送信息
        /// </summary>
        /// <param name="strstrTopic"></param>
        /// <param name="roketMQHelper"></param>
        private static void SendMsg(string strstrTopic, RoketMQHelper roketMQHelper)
        {
            int i = 0;
            while(true)
            {
                i++;
                try
                {
                    roketMQHelper.ProducerMsg(strstrTopic, Guid.NewGuid().ToString(), "3309", $"我是第{i}条信息");
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message+"\n\r"+ex.StackTrace);
                }
               
                Thread.Sleep(100);
            }
          
        }
        /// <summary>
        /// 订阅信息
        /// </summary>
        /// <param name="MsgId"></param>
        /// <param name="Keys"></param>
        /// <param name="Tags"></param>
        /// <param name="BornTimestamp"></param>
        /// <param name="MsgBody"></param>
        private static void _RoketMQHelper_DelConsumerMsgEvent(string MsgId, string Keys, string Tags, DateTime BornTimestamp, string MsgBody)
        {
            Console.WriteLine(MsgBody);
        }
    }
}
